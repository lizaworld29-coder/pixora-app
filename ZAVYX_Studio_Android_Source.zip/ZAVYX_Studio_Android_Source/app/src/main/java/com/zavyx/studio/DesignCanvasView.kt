package com.zavyx.studio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class DesignCanvasView(context: Context) : View(context) {
    enum class Preset { NONE, TSHIRT, POSTER, STICKER }

    private data class TextItem(
        var text: String,
        var x: Float,
        var y: Float,
        var size: Float = 42f,
        var color: Int = Color.rgb(35, 30, 45)
    )

    private data class ImageItem(
        val bitmap: Bitmap,
        var x: Float,
        var y: Float,
        var width: Float,
        var height: Float
    )

    private val texts = mutableListOf<TextItem>()
    private val images = mutableListOf<ImageItem>()
    private var backgroundColor = Color.WHITE
    private var preset = Preset.NONE
    private var activeText: TextItem? = null
    private var lastX = 0f
    private var lastY = 0f

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 42f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        color = Color.rgb(35, 30, 45)
    }
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        setBackgroundColor(Color.WHITE)
    }

    fun addText(value: String) {
        val item = TextItem(value, width * 0.12f, height * 0.48f)
        texts.add(item)
        activeText = item
        invalidate()
    }

    fun addImage(bitmap: Bitmap) {
        val maxWidth = max(80f, width * 0.58f)
        val ratio = bitmap.height.toFloat() / max(1, bitmap.width)
        val w = min(maxWidth, bitmap.width.toFloat())
        val h = min(height * 0.5f, w * ratio)
        images.add(ImageItem(bitmap, (width - w) / 2f, (height - h) / 2f, w, h))
        invalidate()
    }

    fun setBackgroundColorValue(color: Int) {
        backgroundColor = color
        preset = Preset.NONE
        invalidate()
    }

    fun setPreset(value: Preset) {
        preset = value
        backgroundColor = when (value) {
            Preset.TSHIRT -> Color.rgb(245, 242, 250)
            Preset.POSTER -> Color.rgb(255, 235, 242)
            Preset.STICKER -> Color.rgb(230, 245, 255)
            Preset.NONE -> Color.WHITE
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawDesign(canvas, width.toFloat(), height.toFloat(), false)
    }

    private fun drawDesign(canvas: Canvas, targetWidth: Float, targetHeight: Float, export: Boolean) {
        val sx = targetWidth / max(1f, width.toFloat())
        val sy = targetHeight / max(1f, height.toFloat())
        val save = canvas.save()
        canvas.scale(sx, sy)
        canvas.drawColor(backgroundColor)

        when (preset) {
            Preset.TSHIRT -> drawTshirtGuide(canvas)
            Preset.POSTER -> drawPosterGuide(canvas)
            Preset.STICKER -> drawStickerGuide(canvas)
            Preset.NONE -> {}
        }

        images.forEach { item ->
            val dst = RectF(item.x, item.y, item.x + item.width, item.y + item.height)
            canvas.drawBitmap(item.bitmap, null, dst, imagePaint)
        }

        texts.forEach { item ->
            textPaint.textSize = item.size
            textPaint.color = item.color
            textPaint.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
            val lines = item.text.split("\n")
            var y = item.y
            lines.forEach { line ->
                canvas.drawText(line, item.x, y, textPaint)
                y += item.size * 1.2f
            }
            if (!export && item == activeText) {
                val maxLine = lines.maxOfOrNull { textPaint.measureText(it) } ?: 0f
                val box = RectF(item.x - 8, item.y - item.size, item.x + maxLine + 8, item.y + item.size * 0.35f)
                val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(124, 58, 237)
                    style = Paint.Style.STROKE
                    strokeWidth = 2f
                }
                canvas.drawRect(box, border)
            }
        }
        canvas.restoreToCount(save)
    }

    private fun drawTshirtGuide(canvas: Canvas) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val cx = width / 2f
        val top = height * 0.18f
        val w = width * 0.48f
        val h = height * 0.66f
        val path = android.graphics.Path().apply {
            moveTo(cx - w * .23f, top)
            lineTo(cx - w * .52f, top + h * .12f)
            lineTo(cx - w * .38f, top + h * .36f)
            lineTo(cx - w * .24f, top + h * .29f)
            lineTo(cx - w * .24f, top + h)
            lineTo(cx + w * .24f, top + h)
            lineTo(cx + w * .24f, top + h * .29f)
            lineTo(cx + w * .38f, top + h * .36f)
            lineTo(cx + w * .52f, top + h * .12f)
            lineTo(cx + w * .23f, top)
            quadraticTo(cx, top + h * .2f, cx - w * .23f, top)
            close()
        }
        canvas.drawPath(path, p)
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawPath(path, outline)
        textPaint.textSize = 15f
        textPaint.color = Color.GRAY
        canvas.drawText("T-shirt mockup • place your design", 12f, height - 16f, textPaint)
    }

    private fun drawPosterGuide(canvas: Canvas) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            setShadowLayer(8f, 0f, 3f, Color.LTGRAY)
        }
        val rect = RectF(width * .09f, height * .07f, width * .91f, height * .91f)
        canvas.drawRoundRect(rect, 12f, 12f, p)
        textPaint.color = Color.rgb(220, 70, 130)
        textPaint.textSize = 16f
        canvas.drawText("POSTER CANVAS", rect.left + 14, rect.top + 28, textPaint)
    }

    private fun drawStickerGuide(canvas: Canvas) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            setShadowLayer(3f, 0f, 2f, Color.LTGRAY)
        }
        canvas.drawRoundRect(RectF(width * .12f, height * .12f, width * .88f, height * .88f), 48f, 48f, p)
        textPaint.color = Color.rgb(40, 110, 170)
        textPaint.textSize = 16f
        canvas.drawText("STICKER CANVAS", width * .2f, height * .2f, textPaint)
    }

    fun renderExportBitmap(targetWidth: Int, targetHeight: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawDesign(canvas, targetWidth.toFloat(), targetHeight.toFloat(), true)
        return bitmap
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                activeText = texts.asReversed().firstOrNull { item ->
                    textPaint.textSize = item.size
                    val measured = textPaint.measureText(item.text)
                    event.x >= item.x - 18 && event.x <= item.x + measured + 18 &&
                        event.y >= item.y - item.size && event.y <= item.y + item.size * 0.5f
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                activeText?.let { item ->
                    item.x += event.x - lastX
                    item.y += event.y - lastY
                    item.x = item.x.coerceIn(0f, max(0f, width - 20f))
                    item.y = item.y.coerceIn(item.size, max(item.size, height - 10f))
                    invalidate()
                }
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_UP -> return true
        }
        return true
    }
}
