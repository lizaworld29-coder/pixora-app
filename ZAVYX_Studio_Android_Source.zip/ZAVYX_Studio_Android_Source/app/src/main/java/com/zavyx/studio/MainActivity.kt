package com.zavyx.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var designView: DesignCanvasView
    private val pickImageRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 243, 250))
        }

        val header = TextView(this).apply {
            text = "ZAVYX STUDIO"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(Color.rgb(27, 22, 42))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 62))

        val hint = TextView(this).apply {
            text = "Create • Design • Inspire     |     Offline editor"
            textSize = 12f
            setTextColor(Color.rgb(85, 75, 105))
            setPadding(16, 8, 16, 8)
        }
        root.addView(hint)

        designView = DesignCanvasView(this)
        val canvasParams = LinearLayout.LayoutParams(-1, 0, 1f).apply {
            setMargins(12, 6, 12, 8)
        }
        root.addView(designView, canvasParams)

        val scroller = HorizontalScrollViewCompat(this)
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 12)
        }

        tools.addView(toolButton("＋ Text") { askForText() })
        tools.addView(toolButton("＋ Image") { openImagePicker() })
        tools.addView(toolButton("Background") { showBackgrounds() })
        tools.addView(toolButton("T-shirt") { designView.setPreset(DesignCanvasView.Preset.TSHIRT) })
        tools.addView(toolButton("Poster") { designView.setPreset(DesignCanvasView.Preset.POSTER) })
        tools.addView(toolButton("Sticker") { designView.setPreset(DesignCanvasView.Preset.STICKER) })
        tools.addView(toolButton("Save PNG") { saveDesign() })
        scroller.addView(tools)
        root.addView(scroller)

        setContentView(root)
    }

    private fun toolButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setOnClickListener { action() }
        }
    }

    private fun askForText() {
        val input = EditText(this).apply { hint = "Type your text" }
        AlertDialog.Builder(this)
            .setTitle("Add text")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) designView.addText(value)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showBackgrounds() {
        val labels = arrayOf("White", "Soft pink", "Lavender", "Sky blue", "Black", "Mint")
        val colors = intArrayOf(
            Color.WHITE, Color.rgb(255, 226, 239), Color.rgb(232, 224, 255),
            Color.rgb(220, 240, 255), Color.BLACK, Color.rgb(220, 250, 235)
        )
        AlertDialog.Builder(this)
            .setTitle("Choose background")
            .setItems(labels) { _, which -> designView.setBackgroundColorValue(colors[which]) }
            .show()
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, pickImageRequest)
    }

    @Deprecated("Deprecated in Android API but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImageRequest && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.openInputStream(uri)?.use { stream ->
                        val bitmap = android.graphics.BitmapFactory.decodeStream(stream)
                        if (bitmap != null) designView.addImage(bitmap)
                        else Toast.makeText(this, "Could not open this image.", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Exception) {
                    Toast.makeText(this, "Image could not be loaded.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun saveDesign() {
        val bitmap = designView.renderExportBitmap(1080, 1080)
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ZAVYX_design_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZAVYX Studio")
        }
        try {
            val uri: Uri? = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) throw Exception("Could not create image file")
            val output: OutputStream? = contentResolver.openOutputStream(uri)
            output.use { stream ->
                if (stream == null) throw Exception("Could not save image")
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            }
            Toast.makeText(this, "Saved to Pictures/ZAVYX Studio", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }
}

/** Small horizontal scrolling container without extra libraries. */
private class HorizontalScrollViewCompat(context: android.content.Context) :
    android.widget.HorizontalScrollView(context) {
    init {
        isHorizontalScrollBarEnabled = false
        clipToPadding = false
    }
}
