# ZAVYX Studio — Android starter source

This is a starter Android Studio project for an offline-first graphic design app.

## Included in this starter
- Add text to a canvas
- Drag text around the canvas
- Import an image from the device
- Change canvas background colour
- Starter T-shirt, poster, and sticker canvas guides
- Export a 1080 x 1080 PNG to Pictures/ZAVYX Studio
- No internet permission or online service required

## Open the project
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `ZAVYX_Studio_Android_Source` folder.
4. Allow Gradle sync to finish, then run on an Android device or emulator.

## Important
This is an initial prototype, not a PixelLab replacement yet. It does not currently include editable font selection, object layers, text resizing/rotation handles, transparent-canvas export, advanced cutout/background removal, accounts, payments, cloud sync, or an APK file. Those should be added and tested in later stages. Building the APK requires Android Studio and the Android SDK.

## Version
0.1.0 — initial offline editor prototype.
